NITHISH KUMAR K — UI/UX Portfolio

The latest resume is already included:
assets/resume/resume.pdf

Open index.html in Chrome/Edge.
The View Resume and Download buttons now point to the included PDF.

Project screenshots can be added later to:
assets/projects/ev-charge/
assets/projects/bizai/
